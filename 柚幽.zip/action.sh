#!/system/bin/sh
cp -f /data/adb/modules/One_click_hide/shell/林羽三角洲 /data/adb/
mv /data/adb/modules/One_click_hide/shell/林羽三角洲 /data/adb/
chmod 777 /data/adb/林羽三角洲/*
#设备属性
setprop persist.logd.size ""
setprop persist.logd.size.crash ""
setprop persist.logd.size.main ""
setprop persist.logd.size.system ""

echo "完成，等待一秒退出"
sleep 1