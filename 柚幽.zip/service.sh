#!/system/bin/sh
echo 柚幽