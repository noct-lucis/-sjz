#!/system/bin/sh
# customize.sh - Magisk/KernelSU 子模块批量安装脚本

# ==================== 环境检测 ====================
MODULE_DIR="$MODPATH/module"

AP_PKGS="me.bmax.apatch me.garfieldhan.apatch.next"
KSU_NEXT_PKGS="com.sukisu.ultra com.rifsxd.ksunext"
KSU_CLASSIC_PKGS="me.weishu.kernelsu"
MAGISK_PKGS="com.topjohnwu.magisk io.github.vvb2060.magisk io.github.huskydg.magisk"

detect_running_env() {
    for pkg in $AP_PKGS; do
        pidof "$pkg" >/dev/null 2>&1 && { echo "ap"; return; }
    done
    for pkg in $KSU_NEXT_PKGS; do
        pidof "$pkg" >/dev/null 2>&1 && { echo "ksu_next"; return; }
    done
    for pkg in $KSU_CLASSIC_PKGS; do
        pidof "$pkg" >/dev/null 2>&1 && { echo "ksu_classic"; return; }
    done
    for pkg in $MAGISK_PKGS; do
        pidof "$pkg" >/dev/null 2>&1 && { echo "magisk"; return; }
    done
    echo "unknown"
}

# ==================== 子模块安装封装 ====================
install_submodule() {
    local zipfile="$1"
    local env_type="$2"

    case "$env_type" in
        "magisk")
            magisk --install-module "$zipfile" >/dev/null 2>&1
            ;;
        "ksu_classic"|"ksu_next")
            /data/adb/ksud module install "$zipfile" >/dev/null 2>&1
            ;;
        "ap")
            /data/adb/apd module install "$zipfile" >/dev/null 2>&1
            ;;
        "unknown")
            /data/adb/ksud module install "$zipfile" >/dev/null 2>&1 && return 0
            magisk --install-module "$zipfile" >/dev/null 2>&1 && return 0
            return 1
            ;;
        *)
            return 1
            ;;
    esac
}

# ==================== 主流程 ====================
ENV_TYPE=$(detect_running_env)
if [ "$ENV_TYPE" = "unknown" ]; then
    ui_print "未检测到运行中的管理器，将尝试通用安装方式..."
else
    ui_print "检测到环境类型：$ENV_TYPE"
fi

# 检查子模块目录
if [ ! -d "$MODULE_DIR" ]; then
    ui_print "错误：$MODULE_DIR 目录不存在"
    abort "缺少子模块目录"
fi

# 检查是否有 zip（用 glob 判空，比 ls 更稳）
set -- "$MODULE_DIR"/*.zip
if [ ! -e "$1" ]; then
    ui_print "错误：$MODULE_DIR 中无 ZIP 模块"
    abort "无子模块可安装"
fi

# 打印主模块信息
if [ -f "$MODPATH/module.prop" ]; then
    MODULE_NAME=$(grep "^name=" "$MODPATH/module.prop" | cut -d '=' -f2-)
    MODULE_VERSION=$(grep "^version=" "$MODPATH/module.prop" | cut -d '=' -f2-)
    ui_print "主模块：$MODULE_NAME v$MODULE_VERSION"
fi

ui_print "开始安装子模块..."
SUCCESS_COUNT=0
FAIL_COUNT=0

for ZIPFILE in "$MODULE_DIR"/*.zip; do
    [ -f "$ZIPFILE" ] || continue
    SUB_MOD_NAME=$(basename "$ZIPFILE" .zip)
    ui_print "- 正在处理：$SUB_MOD_NAME"

    if install_submodule "$ZIPFILE" "$ENV_TYPE"; then
        ui_print "  ✅ $SUB_MOD_NAME 安装成功"
        SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
    else
        ui_print "  ❌ $SUB_MOD_NAME 安装失败"
        FAIL_COUNT=$((FAIL_COUNT + 1))
    fi
done

ui_print "子模块安装完成：成功 $SUCCESS_COUNT 个，失败 $FAIL_COUNT 个"

# ==================== 写入 system.prop ====================
SYSTEM_PROP_FILE="$MODPATH/system.prop"
HASH_VALUE=$(getprop ro.boot.vbmeta.digest)

if [ -z "$HASH_VALUE" ]; then
    ui_print "警告：无法获取 ro.boot.vbmeta.digest，跳过写入"
else
    # 追加而非覆盖，避免冲掉已有内容
    if ! grep -q "^ro.boot.vbmeta.digest=" "$SYSTEM_PROP_FILE" 2>/dev/null; then
        echo "ro.boot.vbmeta.digest=$HASH_VALUE" >> "$SYSTEM_PROP_FILE"
    fi
fi

if ! grep -q "^ro.boot.veritymode=" "$SYSTEM_PROP_FILE" 2>/dev/null; then
    echo "ro.boot.veritymode=enforcing" >> "$SYSTEM_PROP_FILE"
fi

ui_print "system.prop 已更新"

# ==================== AVB 处理 ====================
# 注意：保留 $MODPATH 原值，不要用 dirname $0 覆盖
AVBCTL="$MODPATH/system/bin/avbctl"
if [ -x "$AVBCTL" ]; then
    "$AVBCTL" disable-verity --force >/dev/null 2>&1
    "$AVBCTL" disable-verification --force >/dev/null 2>&1
    ui_print "AVB 校验已禁用"
else
    ui_print "未找到 avbctl，跳过 AVB 处理"
fi

ui_print " "
ui_print "刷入完成，快去奔放吧 🎉"